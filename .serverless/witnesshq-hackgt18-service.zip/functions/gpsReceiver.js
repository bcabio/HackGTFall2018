'use strict';

module.exports = (context, req) => {
  const body = req.body;

  context.res = {
    body: JSON.stringify({'message': 'post complete'})
  };

  context.done();
};